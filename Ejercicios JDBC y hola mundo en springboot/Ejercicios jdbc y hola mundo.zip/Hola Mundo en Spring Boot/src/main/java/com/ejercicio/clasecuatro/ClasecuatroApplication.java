package com.ejercicio.clasecuatro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClasecuatroApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClasecuatroApplication.class, args);
	}

}
