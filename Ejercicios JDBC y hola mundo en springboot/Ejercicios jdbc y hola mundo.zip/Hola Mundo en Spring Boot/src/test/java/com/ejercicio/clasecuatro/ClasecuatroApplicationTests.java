package com.ejercicio.clasecuatro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClasecuatroApplicationTests {

	@Test
	void contextLoads() {
	}

}
