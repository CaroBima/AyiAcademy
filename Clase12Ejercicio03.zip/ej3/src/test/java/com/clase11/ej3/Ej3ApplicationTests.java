package com.clase11.ej3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ej3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
